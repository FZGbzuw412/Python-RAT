# Python-RAT
Advanced Remote Administration tool for Windows Systems written in pure Python

## Disclamer

THIS SOFTWARE IS INTENDED ONLY FOR EDUCATION PURPOSES! DO NOT USE IT TO INFLICT 
DAMAGE TO ANYONE! USING MY APPLICATION YOU ARE AUTHOMATICALLY AGREE WITH ALL RULES AND
TAKE RESPONSIBITITY FOR YOUR ACTION! THE VIOLATION OF LAWS CAN CAUSE SERIOUS CONSEQUENCES!
THE DEVELOPER ASSUMES NO LIABILITY AND IS NOT RESPONSIBLE FOR ANY MISUSE OR DAMAGE 
CAUSED BY THIS PROGRAM.

## Intended for:
Windows systems

## Requirements
+ Pillow
+ pywin32
+ opencv-python
+ comtypes 
+ pycaw ([C++ Buils tools](https://visualstudio.microsoft.com/ru/visual-cpp-build-tools/) are required) (optional feature)
+ pyautogui
+ vidstream ([VS Code](https://code.visualstudio.com/) is required) (optional feature)

## Usage for server
```
#clone or download zip archive
https://github.com/FZGbzuw412/Python-RAT

#go to directory with files
cd Python-RAT 

#install essential requirements
pip3 install -r server_requirements.txt

#launch 
server.py
```

## Usage for client
```
#clone or download zip archive
https://github.com/FZGbzuw412/Python-RAT

#go to directory with files
cd Python-RAT

#install essential requirements
pip3 install -r client_requirements.txt

#launch 
client.pyw
```

## Features
![изображение](https://user-images.githubusercontent.com/92334349/151528654-e2c6ffb4-33df-430b-a965-07fac7773c19.png)

![изображение](https://user-images.githubusercontent.com/92334349/151528715-c83b5d21-4df4-4143-acf4-a67907e180de.png)

## Licence

This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License. To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/ or send a letter to Creative Commons, PO Box 1866, Mountain View, CA 94042, USA.
